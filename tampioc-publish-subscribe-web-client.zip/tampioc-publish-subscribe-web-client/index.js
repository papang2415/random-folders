console.log("index.js");

// var client = mqtt.connect('wss://test.mosquitto.org:8081/mqtt')
var client = mqtt.connect('wss://test.mosquitto.org:8081/mqtt')




var pub_topic_input = document.getElementById('pub-topic-input');
var pub_input = document.getElementById('pub-input');
var pub_button = document.getElementById('pub-button');
var sub_topic_input = document.getElementById('sub-topic-input');
var sub_button = document.getElementById('sub-button');


client.on('connect', function () {
  console.log('connected')
  client.subscribe(pub_topic_input, function (err) {
    if (!err) {
      client.publish(pub_topic_input, 'Welcome')
    }
  })
})

client.on('message', function (topic, paylaod) {
  console.log(paylaod.toString())
})



pub_button.addEventListener('click', () => {
  console.log(pub_input.value);
  var table = document.getElementById('table');
  var row = table.insertRow(1);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  cell1.innerHTML = pub_topic_input.value;
  cell2.innerHTML = pub_input.value;
  pub_input.value = "";

})

sub_button.addEventListener('click', () => {
  console.log("Subscribed to topic: "+sub_topic_input.value);
})